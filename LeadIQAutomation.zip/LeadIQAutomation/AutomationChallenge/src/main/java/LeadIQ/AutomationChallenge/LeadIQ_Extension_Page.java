package LeadIQ.AutomationChallenge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LeadIQ_Extension_Page {
	private WebDriver driver;
	
	//Web Elements of LeadIQ Extension page
	
	@FindBy(xpath = "/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[1]/div/div/input") 
	WebElement usernameField; 
	
	@FindBy(xpath = "/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[2]/div/div/input") 
	WebElement passwordField; 
	
	@FindBy(xpath = "/html/body/div/div/div[2]/div[2]/div[2]/div/div[4]/div[1]/div") 
	WebElement loginButton; 
	
	@FindBy(xpath="/html/body/div[1]/div[3]/div[2]/div[3]/div[2]/div/div/div/div/div[2]/div[2]")
	WebElement seeExampleButton;
	
	@FindBy(xpath = "/html/body/div[1]/div[3]/div[2]/div[3]/div[2]/div[2]/div[1]/div/span")
	WebElement captureButton;
	
	@FindBy(xpath = "/html/body/div[1]/div[3]/div[1]/div[2]/div/div[2]/div/img")
	WebElement homeIcon;
	
	public LeadIQ_Extension_Page(WebDriver driver){
	       this.driver=driver;
	       
	       //Initialise Elements
	       PageFactory.initElements(driver, this);
	}
	
	//input username function	
	public void setUserName(String name) {
		usernameField.sendKeys(name);
	}
	
	//input password function
	public void setPassword(String password) {
		passwordField.sendKeys(password);
	}
	
	//click on Login Button function
	public void clickLoginButton() {
		loginButton.click();
	}
	
	//click on See Example Button function
	public void clickSeeExampleButton() {
		seeExampleButton.click();
	}
	
	//click on Capture Button function
	public void clickCaptureProfileButton() {
		captureButton.click();
	}
	
	//click on Home Icon function
	public void clickHomeIcon() {
		homeIcon.click();
	}
	
}
