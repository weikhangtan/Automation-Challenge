package LeadIQ.AutomationChallenge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LeadIQ_Webapp_Page {
	
	private WebDriver driver;
	
	//LeadIQ Webapp Web Elements
	
	@FindBy(xpath = "/html/body/div[1]/div/div[3]/div[2]/div/div[1]/h1") 
	WebElement campaignTitle; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[3]/div[2]/div/div[1]/div/div[3]/div/div")
	WebElement createCampaignButton;
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/ul/li[1]/span")
	WebElement campaignMenu;
	
	@FindBy(xpath = "/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div[1]")
	WebElement defaultCampaign;
	
	@FindBy(xpath = "//html/body/div[1]/div/div[3]/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div[3]/div[1]/div[7]/div[2]/div/div")
	WebElement myFirstName;
	
	@FindBy(xpath = "//*[text()='DBS Bank']")
	WebElement myCompanyName;
	
	@FindBy(xpath = "//*[text()='Test Engineer']")
	WebElement myTitle;
	
	@FindBy(xpath="//*[@id=\"app\"]/div/div[3]/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div[3]/div[2]/div/div/div[7]/div[2]")
	WebElement myLocation;
	
	@FindBy(xpath = "/html/body/div[1]/div/div[3]/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div[3]/div[1]/div[7]/div[3]/div/div/img")
	WebElement ProfilePic;

	public LeadIQ_Webapp_Page(WebDriver driver){
	       this.driver=driver;
	       
	       //Initialise Elements
	       PageFactory.initElements(driver, this);
	}
	
	//get the text of campaign text
	public void getCampaignTitle() {
		campaignTitle.getText();
	}
	
	//click on Create Campaign Button
	public void clickCreateCampaignButton() {
		createCampaignButton.click();
	}
	
	//click on Campaign Menu
	public void clickCampaignMenu() {
		campaignMenu.click();
	}
	
	//click on Default Campaign - My Leads
	public void clickDefaultCampaign() {
		defaultCampaign.click();
	}
	
	//get captured First Name
	public String getMyFirstName() {
		return myFirstName.getText().replace(" Tan", "");
	}
	
	//get captured Company Name
	public String getMyCompanyName() {
		return myCompanyName.getText();
	}
	
	//get captured Title
	public String getMyTitle() {
		return myTitle.getText();
	}
	
	//get captured Location
	public String getMyLocation() {
		return myLocation.getText();
	}
	
	
}
