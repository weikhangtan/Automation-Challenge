package LeadIQ.AutomationChallenge;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LinkedInPage {
	private WebDriver driver;
	
	//LinkedIn Page Web Elements
	
	@FindBy(xpath = "//*[@id=\"username\"]") 
	WebElement linkedInUsernameField; 
	
	@FindBy(xpath = "//*[@id=\"password\"]") 
	WebElement linkedInPasswordField;
	
	@FindBy(xpath = "//*[@id=\"app__container\"]/main/div[2]/form/div[3]/button") 
	WebElement linkedInSignInButton;
	
	@FindBy(xpath="/html/body/div[8]/div[4]/div/div/div/aside[1]/div[1]/div/div[1]/a/div[1]/img")
	WebElement linkedInProfilePic;
	
	@FindBy(xpath="/html/body/header/div/nav/ul/li[6]/div/div/button/img")
	WebElement myLinkedInProfilePicIcon;
	
	@FindBy(xpath="/html/body/header/div/nav/ul/li[6]/div/div/div/div/ul/li[1]/a/div[2]/span")
	WebElement viewProfileButton;
	
	@FindBy(xpath="/html/body/header/div/form/div/div/div/div/div[1]/div/input")
	WebElement searchBar;
	
	@FindBy(xpath="/html/body/div[8]/div[4]/div/div[2]/div/div[2]/div/div/div/div/ul/li[2]/div/div/div[2]/a/h3/span/span/span[1]")
	WebElement findName;
	
	@FindBy(xpath = "/html/body/div[8]/div[4]/div/div/div/div/div[2]/main/div[1]/section/div[2]/div[2]/div[1]/ul[1]/li[1]")
	WebElement myFirstName;
	
	@FindBy(xpath = "/html/body/div[8]/div[4]/div/div/div/div/div[2]/main/div[1]/section/div[2]/div[2]/div[1]/h2")
	WebElement myTitle;
	
	@FindBy(xpath = "//*[text()='DBS Bank']")
	WebElement myCompanyName;
	
	@FindBy(xpath = "/html/body/div[8]/div[4]/div/div/div/div/div[2]/main/div[1]/section/div[2]/div[2]/div[1]/ul[2]/li[1]")
	WebElement myLocation;
	
	@FindBy(xpath = "/html/body/nav/a[3]")
	WebElement signInButton;
	
	public LinkedInPage(WebDriver driver){
	       this.driver=driver;
	       
	       //Initialise Elements
	       PageFactory.initElements(driver, this);
	}
	
	//input username
	public void setUserName(String name) {
		linkedInUsernameField.click();
		linkedInUsernameField.sendKeys(name);
	}
	
	//input password
	public void setPassword(String password) {
		linkedInPasswordField.click();
		linkedInPasswordField.sendKeys(password);
	}
	
	//click on Sign In Button
	public void clickSigninButton() {
		linkedInSignInButton.click();
	}
	
	//click on my profile picture to navigate to my profile page 
	public void clickProfilePic() {
		linkedInProfilePic.click();
	}
	
	//click on view profile button
	public void clickViewProfileButton() {
		viewProfileButton.click();
	}
	
	//input text in search bar to search name
	public void searchName(String name) {
		searchBar.sendKeys(name);
		searchBar.sendKeys(Keys.ENTER);
	}
	
	//get my First Name
	public String getMyFirstName() {
		return myFirstName.getText().replace(" TAN", "");
	}
	
	//get my Title 
	public String getMyTitle() {
		return myTitle.getText().replace(" at DBS Bank", "");
	}
	
	//get my Company Name
	public String getMyCompanyName() {
		return myCompanyName.getText();
	}
	
	//get my Location
	public String getMyLocation() {
		return myLocation.getText();
	}
	
	//click on Linkedin Landing Page Sign In Button
	public void clickLandingPageSignInButton() {
		signInButton.click();
	}
}
