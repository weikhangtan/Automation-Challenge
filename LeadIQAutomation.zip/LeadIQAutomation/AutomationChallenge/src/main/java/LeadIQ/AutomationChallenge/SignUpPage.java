package LeadIQ.AutomationChallenge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class SignUpPage {
	private WebDriver driver;
	
	
	//Sign Up page Web Elements
	//Sign Up Page 1 
	
	@FindBy(xpath = "//*[@id=\"app\"]/div/div[2]/div/div/form/div[1]/div[1]/div/div/div[1]/input") 
	WebElement firstNameField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[1]/div[2]/div/div/div/input") 
	WebElement lastNameField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[2]/div/div/input") 
	WebElement emailField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[3]/div/div/input") 
	WebElement companyNameField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[4]/div/div[1]/input") 
	WebElement passwordField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[5]/div/div/input") 
	WebElement confirmPasswordField; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/form/div[6]/div/label/span[1]/span") 
	WebElement privacyTick; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[1]/div") 
	WebElement submitButton; 
	
	//locating elements in Sign Up Page2 - Select Sale Tool Page
	
	@FindBy(xpath = "//*[@id=\"app\"]/div/div[2]/div[3]/div/div/label[4]/span[2]/img") 
	WebElement page2_gmailIntegrationTool; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div[2]/div") 
	WebElement page2_NextButton; 
	
	//locating elements in Sign Up Page3 - Connecting Account Page
	
	@FindBy(xpath = "//div[text()='Continue']") 
	WebElement page3_ContinueButton; 
	
	//locating elements in Sign Up Page4 - Install Extension Page
	
	@FindBy(xpath = "//div[text()='Install']")
	WebElement page4_InstallButton; 
	
	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div[2]/div")
	WebElement page4_ContinueButton; 
	
	//locating elements in Sign Up Page5 - Invite Members Page

	@FindBy(xpath = "/html/body/div[1]/div/div[2]/div[3]/div/div[3]")
	WebElement page5_SkipLink; 
	
	@FindBy(xpath = "//div[text()='Done']")
	WebElement page6_DoneButton; 
	
	public SignUpPage(WebDriver driver){
	       this.driver=driver;
	       
	       //Initialise Elements
	       PageFactory.initElements(driver, this);
    }
	
	//input first name
	public void setFirstName(String name) {
		firstNameField.sendKeys(name);
	}
	
	//input last name
	public void setLastName(String name) {
		lastNameField.sendKeys(name);
	}
	
	//input email
	public void setEmail(String email) {
		emailField.sendKeys(email);
	}
	
	//input company name
	public void setCompanyName(String name) {
		companyNameField.sendKeys(name);
	}
	
	//input password
	public void setPassword(String password) {
		passwordField.sendKeys(password);
	}
	
	//input confirm password
	public void setConfirmPassword(String password) {
		confirmPasswordField.sendKeys(password);
	}
	
	//tick on privacy checkbox
	public void clickPrivacyTickbox() {
		privacyTick.click();
	}
	
	//click on submit button
	public void clickSubmitButton() {
		submitButton.click();
	}
	
	//click on gmail tool
	public void clickGmailTool() {
		page2_gmailIntegrationTool.click();
	}
	
	//click on next button
	public void clickNextButton() {
		page2_NextButton.click();
	}
	
	//click on page3 continue button
	public void clickPage3ContinueButton() {
		page3_ContinueButton.click();
	}
	
	//click on page4 install button
	public void clickPage4InstallButton() {
		page4_InstallButton.click();
	}
	
	//switch back to current tab
	public void switchBackCurrentTab() {
		String currentPage = driver.getWindowHandle();
		driver.switchTo().window(currentPage);
	}
	
	//click on page4 continue button
	public void clickPage4ContinueButton() {
		page4_ContinueButton.click();
	}
	
	//click on skip link
	public void clickSkip() {
		page5_SkipLink.click();
	}
	
	//click on done button
	public void clickDoneButton() {
		page6_DoneButton.click();
	}
	
}
