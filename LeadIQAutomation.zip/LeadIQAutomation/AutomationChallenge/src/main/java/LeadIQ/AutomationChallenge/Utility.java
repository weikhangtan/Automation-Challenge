package LeadIQ.AutomationChallenge;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;


public class Utility {
	
	//take screenshot function
	public static String captureScreenshot(WebDriver driver)
	{
	    try
	    {
	        TakesScreenshot ts = (TakesScreenshot) driver;

	        File source = ts.getScreenshotAs(OutputType.FILE);

	        File destination = new File("src/Screenshots/" +System.currentTimeMillis()+".png");
	        
	        String desPath = destination.getAbsolutePath();

	        FileHandler.copy(source, destination);

	        return desPath;
	    }
	    catch (IOException e)
	    {
	        System.out.println("Exceptione taking screenshot " + e.getMessage());
	        return e.getMessage();
	    }
	}
	
	//Install extension function
	public static DesiredCapabilities InstallExtension(WebDriver driver) {
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("src/main/extension_6_1_0_0.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		return capabilities;
    }
	
	//get current window function
	public static String getCurrentWindowHandler(WebDriver driver) {
		String currentWinHandler = driver.getWindowHandle();
		return currentWinHandler;
    }
	
	//click on Extension function via Sikuli library
	public static void clickExtension(Screen s) throws FindFailed {
         s.click("LeadIQ.png");      
	}
	
	//switch to new window function
	public static void switchToNewWindow(WebDriver driver) {
		for(String winHandle : driver.getWindowHandles()){
    	    driver.switchTo().window(winHandle);
       	}
		//driver.manage().window().maximize();
    }
	
	//switch to iframe function
	public static void switchToFrame(WebDriver driver, int i) {
		 driver.switchTo().frame(i);
    }
	
	//switch back to previous screen function
	public static void switchBackToPage(WebDriver driver, String handler) {
		 driver.switchTo().window(handler);
    }
	
	//click on Profile Picture function via Sikuli 
	public static void clickMyProfilePic(Screen s) throws FindFailed {
        s.click("ProfilePic.png");      
	}
	
	//scroll down function
	public static void scrollDown(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
	}
	
}
