package LeadIQ.AutomationChallenge;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class CaptureAndVerifyProfileTest {
	private WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	
  @Test
  public void CaptureAndVerifyProfile() throws InterruptedException, FindFailed {
      //install leadIQ extension
	  driver=new ChromeDriver(Utility.InstallExtension(driver));
	  test.log(LogStatus.PASS,"Successfully Installed LeadIQ Extension.");
	  
	  //Launch LinkedIn
	  driver.get("https://www.linkedin.com/");
	  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Launch LinkedIn Page");
	  LinkedInPage linkedinPage=new LinkedInPage(driver);
	  linkedinPage.clickLandingPageSignInButton();
	  Thread.sleep(3000);
	  WebDriverWait wait = new WebDriverWait(driver, 30);
	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"username\"]")));
	  
	  //Fill in LinkedIn UID and PW, and login to LinkedIn
	  linkedinPage.setUserName("twk100896@gmail.com");
	  linkedinPage.setPassword("Password1008");
	  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Filled in LinkedIn credentials");
	  linkedinPage.clickSigninButton();
	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[8]/div[4]/div/div/div/aside[1]/div[1]/div/div[1]/a/div[1]/img")));
	  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Successfully Login to LinkedIn!");
	  
	  //After logged in, click on my Profile Picture to navigate to my Profile Page to get my LinkedIn Profile Details
	  linkedinPage.clickProfilePic();
	  Thread.sleep(6000);
	  Utility.scrollDown(driver);
	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='DBS Bank']")));
	  String linkedIn_MyFirstName = linkedinPage.getMyFirstName();
	  String linkedIn_MyCompanyName = linkedinPage.getMyCompanyName();
	  String linkedIn_MyTitle = linkedinPage.getMyTitle();
	  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Go to My Profile to capture my LinkedIn Details.");
	  String myLinkedInProfileHandler= Utility.getCurrentWindowHandler(driver);
	  
	  //Use Sikuli library to click and launch LeadIQ extension
	  //Need to switch to Extension window 
	  //Need to switch frame in order to input UID and PW
	  Screen s = new Screen();
      ImagePath.add("src/main");
      Utility.clickExtension(s);
      Utility.switchToNewWindow(driver);
      Utility.switchToFrame(driver, 0);  
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[1]/div/div/input")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Switch to LeadIQ Extension Page.");
      
      //Filled in LeadIQ UID & PW
      //Login LeadIQ Extension
      LeadIQ_Extension_Page leadIQExtSignInPage = new LeadIQ_Extension_Page(driver);
      leadIQExtSignInPage.setUserName("hahaha@googlemail.com");
      leadIQExtSignInPage.setPassword("password");
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Filled in LeadIQ credentials.");
      leadIQExtSignInPage.clickLoginButton();
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div[2]/div[3]/div[2]/div/div/div/div/div[2]/div[2]")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Successfully signed in to LeadIQ!");
      String extensionHandler= Utility.getCurrentWindowHandler(driver);
      
      //After logged in, click on See Example Button and will redirected to LinkedIn to view Example
      leadIQExtSignInPage.clickSeeExampleButton();
      Utility.switchToNewWindow(driver);
      Thread.sleep(6000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Click on See Example Button and redirected to LinkedIn Page");
      
      //Search my name in the LinkedIn Search Bar
      linkedinPage.searchName("weikhang tan");
      Thread.sleep(3000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Search my name via LinkedIn Search Bar.");
      Utility.scrollDown(driver);
      
      //After searched my name, LeadIQ Extension already captured the search results
      //Back to LeadIQ Extension to capture my profile
      Utility.switchBackToPage(driver, extensionHandler);
      Thread.sleep(6000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Switch back to LeadIQ Extension.");
      
      //Use sikuli to click on my profile picture in captured list which similar with my LinkedIn Profile picture
      //Click on capture button to capturemy profile
      Screen s2 = new Screen();
      ImagePath.add("src/main");
      Thread.sleep(6000);
      Utility.clickMyProfilePic(s2);
      leadIQExtSignInPage.clickCaptureProfileButton();
      Thread.sleep(6000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Click on my Profile picture and capture my LinkedIn Details.");
      
      //Click Home Icon to go to LeadIQ Webapp
      //Maximize the window
      leadIQExtSignInPage.clickHomeIcon();      
      String webAppHandler = Utility.getCurrentWindowHandler(driver);      
      Utility.switchToNewWindow(driver);
      driver.manage().window().maximize();
      
      //Wait until the element loaded
      //Landed in the LeadIQ webapp 
      //Click on Campaign Menu to view my default campaign
      LeadIQ_Webapp_Page webAppPage = new LeadIQ_Webapp_Page(driver);
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[2]/ul/li[1]/span")));
      Thread.sleep(3000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Clicked on Home icon in Extension and navigated to LeadIQ Webapp.");
      webAppPage.clickCampaignMenu();
      
      //Wait until the element loaded
      //Click on Default Campaign - My Leaders
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div[1]")));
      Thread.sleep(3000);
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Clicked on the Campaign Menu.");
      webAppPage.clickDefaultCampaign();
      
      //Wait until the elements loaded
      //Get my captured profile details
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Weikhang Tan']")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Clicked on My Leads default campaign and navigated to My Leads List");
      String LeadIQ_myFirstName = webAppPage.getMyFirstName();
      String LeadIQ_myCompanyName = webAppPage.getMyCompanyName();
      String LeadIQ_myTitle = webAppPage.getMyTitle();
      Thread.sleep(6000);
      
      //Unable to verify Mobile Number and Email as this 2 information required credit to unlock
      //Assert to verify the First Name in LeadIQ with LinkedIn
      //Assert to verify the Company Name in LeadIQ with LinkedIn
      //Assert to verify the Title in LeadIQ with LinkedIn
      //Assert to verify the Profile Picture is exist
      Assert.assertEquals(linkedIn_MyFirstName, LeadIQ_myFirstName);
      test.log(LogStatus.PASS,"Comparing my LinkedIn First Name with LeadIQ First Name-> "+"LinkedIn FirstName: "+linkedIn_MyFirstName+" ,"+" LeadIQ First Name: "+LeadIQ_myFirstName);
	  Assert.assertEquals(linkedIn_MyCompanyName, LeadIQ_myCompanyName);
	  test.log(LogStatus.PASS,"Comparing my LinkedIn Company Name with LeadIQ Company Name-> "+"LinkedIn CompanyName: "+linkedIn_MyCompanyName+" ,"+" LeadIQ CompanyName: "+LeadIQ_myCompanyName);
	  Assert.assertEquals(linkedIn_MyTitle, LeadIQ_myTitle);
	  test.log(LogStatus.PASS,"Comparing my LinkedIn Title with LeadIQ Title-> "+"LinkedIn Title: "+linkedIn_MyTitle+" ,"+" LeadIQ Title: "+LeadIQ_myTitle);
	  Assert.assertTrue(webAppPage.ProfilePic.isDisplayed());
	  test.log(LogStatus.PASS,"Checking Profile Picture is exist-> "+"Profile Picture: "+webAppPage.ProfilePic.isDisplayed());
	  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Captured Profile is verified successfully!");
  }
  
  @BeforeClass
  public void beforeClass() {
	  
	  //Using WebDriverManager to help to setup and fix my Chrome version
	  //Using Extent Report library to generate report, as it allows easy tracking of test case, can display screenshots and also can customize the report
	  //Report location: src/main/Report/CaptureAndVerifyProfileReport.html
	  //Screenshots location: src/main/Screenshots
	  WebDriverManager.chromedriver().setup();
	  report = new ExtentReports("src/Report/CaptureAndVerifyProfileReport.html");
	  test = report.startTest("Automate to Open LeadIQ Extension");	
  }

  @AfterClass
  public void afterClass() {
	  report.endTest(test);
	  report.flush();
	  driver.quit();
  }

}
