package LeadIQ.AutomationChallenge;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.Assert;
import java.util.UUID;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateAccountTest {
	
  private WebDriver driver;
  
  static ExtentTest test;
  static ExtentReports report;
  
  
  @Test
  public void CreateAccount() {
	 
	 driver.get("https://account.leadiq.com/app/signup?referralCode=goneprospectin");
	 String uuid=UUID.randomUUID().toString();
	 SignUpPage registerPage = new SignUpPage(driver);
	 LeadIQ_Webapp_Page campaignPage = new LeadIQ_Webapp_Page(driver);
	 
	 try {
		 //Sign Up Page 1 - Input All Details 
		 registerPage.setFirstName(uuid);
		 registerPage.setLastName(uuid);
		 registerPage.setEmail(uuid+"@googlemail.com");
		 registerPage.setCompanyName(uuid);
		 registerPage.setPassword("password");
		 registerPage.setConfirmPassword("password");
		 registerPage.clickPrivacyTickbox();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Filled in all of details in SignUp Page1 ");
		 registerPage.clickSubmitButton();
		 test.log(LogStatus.PASS, "Click on Submit Button and Navigating to SignUp Page2");
		 Thread.sleep(10000);
		 
		 //Sign Up Page 2 - Select Gmail Tool and proceed
		 registerPage.clickGmailTool();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Selected Gmail Tool");
		 registerPage.clickNextButton();
		 test.log(LogStatus.PASS, "Click on Next Button and Navigating to SignUp Page3");
		 
		 //Sign Up Page 3 - Link Account
		 Thread.sleep(6000);
		 registerPage.clickPage3ContinueButton();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver)) + "Click on Continue Button and Navigating to SignUp Page4");
		 
		 //Sign Up Page 4 - Click Install LeadIQ Extension will redirected to Google store
		 //Switch back to LeadIQ SignUp Page4, then click on Continue
		 Thread.sleep(6000);
		 registerPage.clickPage4InstallButton();
		 Thread.sleep(8000);
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Click on Install Button and Navigating to Google Store to download extension");
		 registerPage.switchBackCurrentTab();
		 Thread.sleep(8000);
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Switch back to LeadIQ Sign Up Page4");
		 Thread.sleep(8000);
		 registerPage.clickPage4ContinueButton();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Click on Continue Button and Navigating to SignUp Page5");
		 
		 //Sign Up Page 5 - Invite people, click on Skip Link, to skip the invite process
		 Thread.sleep(8000);
		 registerPage.clickSkip();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Click on Skip link and Navigating to SignUp Page6");
		 
		 //Sign Up Page 6 - Complete Page, click on Done Button 
		 Thread.sleep(6000);
		 registerPage.clickDoneButton();
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Click on Done Button and Navigating to LeadIQ Campaign Page");
		 
		 //Verify if user has landed LeadIQ Campaign page, if yes, sign up is successfully done
		 Thread.sleep(6000);
		 Assert.assertTrue(campaignPage.campaignTitle.isDisplayed());
		 test.log(LogStatus.PASS, test.addScreenCapture(Utility.captureScreenshot(driver))+ "Navigated LeadIQ Campaign Page, successfully registered!");
	 }
	 catch(InterruptedException e) {
		 test.log(LogStatus.FAIL, test.addScreenCapture(Utility.captureScreenshot(driver))+ e);
	 }
  }
  
  @BeforeClass
  public void beforeClass() {
	  
	  //Using WebDriverManager to help to setup and fix my Chrome version
	  //Using Extent Report library to generate report, as it allows easy tracking of test case, can display screenshots and also can customize the report
	  //Report location: src/main/Report/SignUpReport.html
	  //Screenshots location: src/main/Screenshots
	  WebDriverManager.chromedriver().setup();
	  driver = new ChromeDriver();  
	  report = new ExtentReports("src/Report/SignUpReport.html");
	  test = report.startTest("Create Account on LeadIQ");	
  }

  @AfterClass
  public void afterClass() {
	  driver.quit();
	  report.endTest(test);
	  report.flush();
  }

}
