package LeadIQ.AutomationChallenge;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import java.io.File;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class InstallExtensionTest {
	
	private WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	
  @Test
  public void InstallExtension() throws InterruptedException {
	  //Installing LeadIQ Extension
	  driver = new ChromeDriver(Utility.InstallExtension(driver));
	  
	  //Go to LeadIQ Chrome store to verify if it is successfully installed
	  driver.get("https://chrome.google.com/webstore/detail/leadiq-lead-capture/befngoippmpmobkkpkdoblkmofpjihnk?itemlang=cs&hl=en");
	  Thread.sleep(6000);
	  WebElement LeadIQ = driver.findElement(By.xpath("//div[text()='Remove from Chrome']"));
	  String actualText = LeadIQ.getText();
	  try {
		  Assert.assertEquals("Remove from Chrome",actualText);
		  test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Extension is installed!");
	  }catch(AssertionError e) {
		  test.log(LogStatus.FAIL,test.addScreenCapture(Utility.captureScreenshot(driver))+"Extension is not installed yet!");
	  }
	  driver.close();
  }
  @BeforeClass
  public void beforeClass() {
	  
	  //Using WebDriverManager to help to setup and fix my Chrome version
	  //Using Extent Report library to generate report, as it allows easy tracking of test case, can display screenshots and also can customize the report
	  //Report location: src/main/Report/InstallExTensionReport.html
	  //Screenshots location: src/main/Screenshots
	  WebDriverManager.chromedriver().setup();
	  report = new ExtentReports("src/Report/InstallExTensionReport.html");
	  test = report.startTest("Automate to Install LeadIQ Extension with .crx file");	
  }

  @AfterClass
  public void afterClass() {
	  
	  report.endTest(test);
	  report.flush();
  }

}
