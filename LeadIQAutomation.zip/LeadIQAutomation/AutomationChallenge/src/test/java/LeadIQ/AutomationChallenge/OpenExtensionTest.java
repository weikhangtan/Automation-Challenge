package LeadIQ.AutomationChallenge;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.*;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class OpenExtensionTest {
	
	private WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	
  @Test
  public void OpenExtension() throws InterruptedException, FindFailed {
	  //Using sikuli library to help to open extension, as extension cannot be located by web element
	  //Install LeadIQ Extension
	  Screen s = new Screen();
      ImagePath.add("src/main");
      LeadIQ_Extension_Page extensionSignInPage = new LeadIQ_Extension_Page(driver); 
	  driver = new ChromeDriver(Utility.InstallExtension(driver));
	  test.log(LogStatus.PASS,"Successfully Installed LeadIQ Extension.");
	  
	  //Sikuli to click on extension
	  //Switch to Extension window
	  //Switch to Extension frame in order to input uid and pw
      Utility.clickExtension(s);
      Utility.switchToNewWindow(driver);
      Thread.sleep(6000);
      Utility.switchToFrame(driver, 0);  
      WebDriverWait wait = new WebDriverWait(driver, 30);
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[1]/div/div/input")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Clicked Extension and navigated to Extension SignIn Page.");  
      
      //Failed to use PageFactory function for this execution
      //Hence, locating my web elements at here
      //Login in LeadIQ Extension
      WebElement usernameField = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[1]/div/div/input"));
      usernameField.sendKeys("hahaha@googlemail.com");
      WebElement passwordField = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[2]/div[2]/div/form/div[2]/div/div/input"));
      passwordField.sendKeys("password");
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Input Email and Password.");
      WebElement loginButton = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[2]/div[2]/div/div[4]/div[1]/div"));
      loginButton.click();
      
      //After logged in, click on Home Icon in order to redirect to LeadIQ Webapp
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div[1]/div[2]/div/div[2]/div/img")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Successfully Login!");
      String LeadIQ_ExtScreen = Utility.getCurrentWindowHandler(driver);
      WebElement homeIcon = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div[2]/div/div[2]/div/img"));
      homeIcon.click();
      
      //Switch to LeadIQ webapp window
      //Maximize the window
      Utility.switchToNewWindow(driver);
      driver.manage().window().maximize();
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[2]/ul/li[1]/span")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Click on Home Icon and go to LeadIQ webapp.");
      
      //After landed, click on Campaign Menu
      WebElement campaignMenu = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/ul/li[1]/span"));
      campaignMenu.click();
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div[1]")));
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Clicked on Campaign Menu.");
      
      //Verify the default Campaign name as "My Leads"
      WebElement defaultCampaign = driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div[1]"));
      String actualText = defaultCampaign.getText();
      Assert.assertEquals(actualText, "My Leads");
      test.log(LogStatus.PASS,test.addScreenCapture(Utility.captureScreenshot(driver))+"Verified! My default Campaign is "+actualText+"!");

  }
  @BeforeClass
  public void beforeClass() {
	  
	  //Using WebDriverManager to help to setup and fix my Chrome version
	  //Using Extent Report library to generate report, as it allows easy tracking of test case, can display screenshots and also can customize the report
	  //Report location: src/main/Report/OpenLeadIQExtensionReport.html
	  //Screenshots location: src/main/Screenshots
	  WebDriverManager.chromedriver().setup();
	  report = new ExtentReports("src/Report/OpenLeadIQExtensionReport.html");
	  test = report.startTest("Automate to Open LeadIQ Extension");	
  }

  @AfterClass
  public void afterClass() {
	  report.endTest(test);
	  report.flush();
	  driver.quit();
  }

}
